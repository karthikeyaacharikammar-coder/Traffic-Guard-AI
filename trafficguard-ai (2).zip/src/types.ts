export interface Violation {
  id?: number;
  video_path: string;
  timestamp: string;
  violation_type: string;
  description: string;
  license_plate: string | null;
  created_at?: string;
}

export interface AnalysisResult {
  timestamp: string;
  type: string;
  description: string;
  licensePlate: string | null;
}
