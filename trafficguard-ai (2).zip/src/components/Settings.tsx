import React, { useState } from 'react';
import { Bell, Shield, Database, Trash2, Save, Check, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export const Settings: React.FC = () => {
  const [sensitivity, setSensitivity] = useState(85);
  const [detections, setDetections] = useState({
    helmet: true,
    seatbelt: true,
    speeding: false,
    redlight: true
  });
  const [notifications, setNotifications] = useState({
    email: false,
    push: true,
    sound: true
  });
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }, 1000);
  };

  const clearHistory = async () => {
    if (confirm('Are you sure you want to clear all violation history? This cannot be undone.')) {
      // In a real app, call API to clear DB
      alert('History cleared successfully (Demo)');
    }
  };

  return (
    <div className="max-w-4xl space-y-8">
      {/* AI Configuration */}
      <section className="glass rounded-3xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-900">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">AI Detection Engine</h3>
            <p className="text-sm text-zinc-500">Configure how the AI analyzes traffic footage.</p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-zinc-700">Confidence Threshold</label>
              <span className="text-sm font-mono font-bold text-zinc-900">{sensitivity}%</span>
            </div>
            <input 
              type="range" 
              min="50" 
              max="99" 
              value={sensitivity}
              onChange={(e) => setSensitivity(parseInt(e.target.value))}
              className="w-full h-2 bg-zinc-100 rounded-lg appearance-none cursor-pointer accent-zinc-900"
            />
            <p className="mt-2 text-xs text-zinc-400">Higher values reduce false positives but may miss subtle violations.</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <ToggleCard 
              label="Helmet Detection" 
              active={detections.helmet} 
              onToggle={() => setDetections(d => ({ ...d, helmet: !d.helmet }))} 
            />
            <ToggleCard 
              label="Seatbelt Detection" 
              active={detections.seatbelt} 
              onToggle={() => setDetections(d => ({ ...d, seatbelt: !d.seatbelt }))} 
            />
            <ToggleCard 
              label="Speeding (Beta)" 
              active={detections.speeding} 
              onToggle={() => setDetections(d => ({ ...d, speeding: !d.speeding }))} 
            />
            <ToggleCard 
              label="Red Light Violation" 
              active={detections.redlight} 
              onToggle={() => setDetections(d => ({ ...d, redlight: !d.redlight }))} 
            />
          </div>
        </div>
      </section>

      {/* Notifications */}
      <section className="glass rounded-3xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-900">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Alert Preferences</h3>
            <p className="text-sm text-zinc-500">Manage how you receive violation notifications.</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl">
            <div>
              <p className="text-sm font-semibold text-zinc-900">Push Notifications</p>
              <p className="text-xs text-zinc-500">Receive alerts directly on your desktop.</p>
            </div>
            <Switch active={notifications.push} onClick={() => setNotifications(n => ({ ...n, push: !n.push }))} />
          </div>
          <div className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl">
            <div>
              <p className="text-sm font-semibold text-zinc-900">Audio Alerts</p>
              <p className="text-xs text-zinc-500">Play a sound when a violation is detected.</p>
            </div>
            <Switch active={notifications.sound} onClick={() => setNotifications(n => ({ ...n, sound: !n.sound }))} />
          </div>
        </div>
      </section>

      {/* Data Management */}
      <section className="glass rounded-3xl p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-900">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Data & Storage</h3>
            <p className="text-sm text-zinc-500">Manage your local database and uploaded files.</p>
          </div>
        </div>

        <div className="flex items-center justify-between p-6 border border-red-100 bg-red-50/30 rounded-2xl">
          <div>
            <p className="text-sm font-bold text-red-900">Clear All Records</p>
            <p className="text-xs text-red-600/70">Permanently delete all violation history and uploaded videos.</p>
          </div>
          <button 
            onClick={clearHistory}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl text-xs font-bold hover:bg-red-700 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            Purge Data
          </button>
        </div>
      </section>

      {/* Save Button */}
      <div className="flex items-center justify-end gap-4">
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 text-emerald-600 text-sm font-bold"
          >
            <Check className="w-4 h-4" />
            Settings Saved
          </motion.div>
        )}
        <button
          onClick={handleSave}
          disabled={isSaving}
          className="flex items-center gap-2 px-8 py-3 bg-zinc-900 text-white rounded-2xl font-bold hover:bg-zinc-800 transition-all disabled:opacity-50"
        >
          {isSaving ? (
            <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          ) : (
            <Save className="w-5 h-5" />
          )}
          Save Changes
        </button>
      </div>
    </div>
  );
};

function ToggleCard({ label, active, onToggle }: { label: string, active: boolean, onToggle: () => void }) {
  return (
    <div 
      onClick={onToggle}
      className={cn(
        "p-4 rounded-2xl border cursor-pointer transition-all",
        active ? "bg-zinc-900 border-zinc-900 text-white" : "bg-white border-zinc-100 text-zinc-500 hover:border-zinc-300"
      )}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-bold uppercase tracking-wider">{label}</span>
        <div className={cn(
          "w-2 h-2 rounded-full",
          active ? "bg-emerald-400 animate-pulse" : "bg-zinc-200"
        )} />
      </div>
    </div>
  );
}

function Switch({ active, onClick }: { active: boolean, onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-12 h-6 rounded-full relative transition-colors duration-200",
        active ? "bg-zinc-900" : "bg-zinc-200"
      )}
    >
      <motion.div
        animate={{ x: active ? 26 : 2 }}
        className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
      />
    </button>
  );
}
