import React, { useRef, useEffect, useState, useCallback } from 'react';
import { Camera, CameraOff, AlertTriangle, Loader2, Play, Square } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GoogleGenAI, Modality } from "@google/genai";
import { cn } from '../lib/utils';

export const LiveFeed: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [detections, setDetections] = useState<{ type: string; timestamp: string }[]>([]);
  const [error, setError] = useState<string | null>(null);
  const sessionRef = useRef<any>(null);
  const streamingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isActiveRef = useRef(false);

  const stopLiveFeed = useCallback(() => {
    isActiveRef.current = false;
    setIsActive(false);
    setIsConnecting(false);

    if (streamingTimeoutRef.current) {
      clearTimeout(streamingTimeoutRef.current);
      streamingTimeoutRef.current = null;
    }

    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => {
        track.stop();
        console.log(`Track ${track.kind} stopped`);
      });
      videoRef.current.srcObject = null;
    }

    if (sessionRef.current) {
      try {
        sessionRef.current.close();
      } catch (e) {
        console.error("Error closing session:", e);
      }
      sessionRef.current = null;
    }
  }, []);

  const startStreaming = useCallback((session: any) => {
    const sendFrame = () => {
      if (!isActiveRef.current || !sessionRef.current) {
        console.log("Streaming stopped: active flag or session missing");
        return;
      }
      
      if (videoRef.current && canvasRef.current && videoRef.current.readyState === 4) {
        const context = canvasRef.current.getContext('2d');
        if (context) {
          context.drawImage(videoRef.current, 0, 0, 320, 180);
          const base64Data = canvasRef.current.toDataURL('image/jpeg', 0.5).split(',')[1];
          try {
            session.sendRealtimeInput({
              media: { data: base64Data, mimeType: 'image/jpeg' }
            });
          } catch (e) {
            console.error("Error sending frame:", e);
          }
        }
      }
      streamingTimeoutRef.current = setTimeout(sendFrame, 1000);
    };
    sendFrame();
  }, []);

  const startLiveFeed = async () => {
    setIsConnecting(true);
    setError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 1280, height: 720 },
        audio: false 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) throw new Error("Gemini API key not found");

      const ai = new GoogleGenAI({ apiKey });
      
      const session = await ai.live.connect({
        model: "gemini-2.5-flash-native-audio-preview-09-2025",
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: "You are a traffic safety monitor. Watch the video feed and immediately alert if you see: 1. Motorcyclists without helmets. 2. Drivers without seatbelts. 3. Dangerous driving. Keep alerts brief.",
        },
        callbacks: {
          onopen: () => {
            console.log("Live session opened");
            isActiveRef.current = true;
            setIsActive(true);
            setIsConnecting(false);
            startStreaming(session);
          },
          onmessage: (message) => {
            if (message.serverContent?.modelTurn?.parts?.[0]?.text) {
              const text = message.serverContent.modelTurn.parts[0].text;
              setDetections(prev => [{ 
                type: text, 
                timestamp: new Date().toLocaleTimeString() 
              }, ...prev].slice(0, 10));
            }
          },
          onerror: (err) => {
            console.error("Live error:", err);
            setError("Live connection error");
            stopLiveFeed();
          },
          onclose: () => {
            console.log("Live session closed");
            stopLiveFeed();
          }
        }
      });

      sessionRef.current = session;
    } catch (err: any) {
      console.error("Failed to start live feed:", err);
      setError(err.message || "Failed to access camera");
      setIsConnecting(false);
      stopLiveFeed();
    }
  };

  useEffect(() => {
    return () => stopLiveFeed();
  }, []);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="relative aspect-video bg-black rounded-3xl overflow-hidden shadow-2xl border border-zinc-800">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className={cn("w-full h-full object-cover", !isActive && "opacity-30")}
          />
          <canvas ref={canvasRef} width="320" height="180" className="hidden" />
          
          <div className="absolute inset-0 flex items-center justify-center">
            {!isActive && !isConnecting && (
              <button
                onClick={startLiveFeed}
                className="group flex items-center gap-3 px-8 py-4 bg-white text-zinc-900 rounded-full font-bold shadow-xl hover:scale-105 transition-all"
              >
                <Play className="w-6 h-6 fill-current" />
                Start Live Monitor
              </button>
            )}
            {isConnecting && (
              <div className="flex flex-col items-center gap-4 text-white">
                <Loader2 className="w-12 h-12 animate-spin" />
                <p className="font-medium">Initializing AI Vision...</p>
              </div>
            )}
          </div>

          {isActive && (
            <div className="absolute top-6 left-6 flex items-center gap-3">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-red-600 text-white rounded-full text-[10px] font-bold uppercase tracking-widest animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full" />
                Live
              </div>
              <div className="px-3 py-1.5 bg-black/50 backdrop-blur-md text-white rounded-full text-[10px] font-bold uppercase tracking-widest border border-white/10">
                AI Monitoring Active
              </div>
            </div>
          )}

          {isActive && (
            <button
              onClick={stopLiveFeed}
              className="absolute bottom-6 right-6 p-4 bg-red-600 text-white rounded-full shadow-xl hover:bg-red-700 transition-colors"
            >
              <Square className="w-6 h-6 fill-current" />
            </button>
          )}
        </div>

        {error && (
          <div className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center gap-3 text-red-600">
            <AlertTriangle className="w-5 h-5" />
            <p className="text-sm font-medium">{error}</p>
          </div>
        )}
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">Live Alerts</h3>
          <div className="flex items-center gap-2 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">
            <div className={cn("w-1.5 h-1.5 rounded-full", isActive ? "bg-emerald-500" : "bg-zinc-300")} />
            {isActive ? "Connected" : "Disconnected"}
          </div>
        </div>

        <div className="space-y-3 max-h-[calc(100vh-300px)] overflow-y-auto pr-2 custom-scrollbar">
          <AnimatePresence initial={false}>
            {detections.length === 0 ? (
              <div className="py-12 text-center text-zinc-400">
                <CameraOff className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p className="text-sm">No live alerts yet.</p>
              </div>
            ) : (
              detections.map((det, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="p-4 bg-white border border-zinc-100 rounded-2xl shadow-sm"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-red-50 text-red-600 rounded-lg flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-zinc-900 leading-tight mb-1">
                        {det.type}
                      </p>
                      <p className="text-[10px] font-mono text-zinc-400">
                        {det.timestamp}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};
