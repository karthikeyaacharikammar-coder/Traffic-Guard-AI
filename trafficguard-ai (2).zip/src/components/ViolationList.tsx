import React from 'react';
import { AlertTriangle, Clock, Car, User, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { Violation } from '../types';
import { cn } from '../lib/utils';

interface ViolationListProps {
  violations: Violation[];
  onViolationClick?: (v: Violation) => void;
}

export const ViolationList: React.FC<ViolationListProps> = ({ violations, onViolationClick }) => {
  if (violations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-zinc-400">
        <ShieldCheck className="w-12 h-12 mb-4 opacity-20" />
        <p className="text-sm">No violations detected yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {violations.map((violation, idx) => (
        <motion.div
          key={violation.id || idx}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: idx * 0.1 }}
          onClick={() => onViolationClick?.(violation)}
          className="group p-4 bg-white border border-zinc-100 rounded-2xl hover:border-zinc-300 hover:shadow-md transition-all cursor-pointer"
        >
          <div className="flex items-start gap-4">
            <div className={cn(
              "w-12 h-12 rounded-xl flex items-center justify-center shrink-0",
              violation.violation_type.toLowerCase().includes('helmet') ? "bg-orange-50 text-orange-600" :
              violation.violation_type.toLowerCase().includes('seatbelt') ? "bg-blue-50 text-blue-600" :
              "bg-red-50 text-red-600"
            )}>
              <AlertTriangle className="w-6 h-6" />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-bold text-zinc-900 uppercase tracking-tight">
                  {violation.violation_type}
                </h4>
                <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-400 bg-zinc-50 px-2 py-0.5 rounded">
                  <Clock className="w-3 h-3" />
                  {violation.timestamp}
                </div>
              </div>
              
              <p className="text-sm text-zinc-600 line-clamp-2 mb-3">
                {violation.description}
              </p>
              
              <div className="flex items-center gap-4">
                {violation.license_plate && (
                  <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-500">
                    <Car className="w-3.5 h-3.5" />
                    <span className="bg-zinc-100 px-2 py-0.5 rounded text-zinc-900 font-mono">
                      {violation.license_plate}
                    </span>
                  </div>
                )}
                <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-500">
                  <User className="w-3.5 h-3.5" />
                  <span>Detected by AI</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
};
