import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileVideo, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface VideoUploadProps {
  onUpload: (file: File) => void;
  isUploading: boolean;
}

export const VideoUpload: React.FC<VideoUploadProps> = ({ onUpload, isUploading }) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onUpload(acceptedFiles[0]);
    }
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive, acceptedFiles } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi']
    },
    maxFiles: 1,
    disabled: isUploading
  });

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        {...getRootProps()}
        className={cn(
          "relative border-2 border-dashed rounded-2xl p-12 transition-all duration-200 cursor-pointer group",
          isDragActive ? "border-emerald-500 bg-emerald-50/50" : "border-zinc-200 hover:border-zinc-300 bg-white",
          isUploading && "opacity-50 cursor-not-allowed"
        )}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center text-center">
          <div className={cn(
            "w-16 h-16 rounded-full flex items-center justify-center mb-4 transition-transform duration-200",
            isDragActive ? "bg-emerald-100 text-emerald-600 scale-110" : "bg-zinc-100 text-zinc-400 group-hover:scale-110"
          )}>
            <Upload className="w-8 h-8" />
          </div>
          
          <h3 className="text-lg font-semibold text-zinc-900 mb-1">
            {isDragActive ? "Drop the video here" : "Upload traffic footage"}
          </h3>
          <p className="text-sm text-zinc-500 mb-6">
            Drag and drop your MP4, MOV or AVI files here
          </p>
          
          <button
            type="button"
            className="px-6 py-2.5 bg-zinc-900 text-white rounded-full text-sm font-medium hover:bg-zinc-800 transition-colors"
          >
            Select Video
          </button>
        </div>
      </div>

      <AnimatePresence>
        {acceptedFiles.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="mt-4 p-4 bg-white border border-zinc-100 rounded-xl flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-zinc-100 rounded-lg flex items-center justify-center text-zinc-500">
                <FileVideo className="w-5 h-5" />
              </div>
              <div>
                <p className="text-sm font-medium text-zinc-900 truncate max-w-[200px]">
                  {acceptedFiles[0].name}
                </p>
                <p className="text-xs text-zinc-500">
                  {(acceptedFiles[0].size / (1024 * 1024)).toFixed(2)} MB
                </p>
              </div>
            </div>
            {isUploading && (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-zinc-200 border-t-zinc-900 rounded-full animate-spin" />
                <span className="text-xs font-medium text-zinc-600">Processing...</span>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
