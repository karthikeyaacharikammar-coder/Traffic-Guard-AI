import React, { useState, useEffect } from 'react';
import { Shield, Activity, FileText, Settings, LayoutDashboard, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { VideoUpload } from './components/VideoUpload';
import { ViolationList } from './components/ViolationList';
import { LiveFeed } from './components/LiveFeed';
import { Settings as SettingsView } from './components/Settings';
import { Login } from './components/Login';
import { Violation } from './types';
import { cn } from './lib/utils';
import { LogOut } from 'lucide-react';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'live' | 'reports' | 'settings'>('dashboard');
  const [isUploading, setIsUploading] = useState(false);
  const [violations, setViolations] = useState<Violation[]>([]);
  const [currentVideo, setCurrentVideo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [wsStatus, setWsStatus] = useState<'connecting' | 'connected' | 'reconnecting'>('connected');
  const [loginLogs, setLoginLogs] = useState<any[]>([]);

  useEffect(() => {
    fetchViolations();
    fetchLoginLogs();

    // Setup WebSocket for real-time updates
    let ws: WebSocket | null = null;
    let reconnectTimeout: NodeJS.Timeout | null = null;
    let heartbeatInterval: NodeJS.Timeout | null = null;
    const connect = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      try {
        ws = new WebSocket(wsUrl);

        ws.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data);
            if (message.type === 'NEW_VIOLATION') {
              setViolations(prev => [message.data, ...prev]);
            }
          } catch (err) {
            // Silent fail for malformed messages
          }
        };

        ws.onopen = () => {
          setWsStatus('connected');
          heartbeatInterval = setInterval(() => {
            if (ws?.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'PING' }));
            }
          }, 30000);
        };

        ws.onclose = () => {
          setWsStatus('reconnecting');
          if (heartbeatInterval) clearInterval(heartbeatInterval);
          reconnectTimeout = setTimeout(connect, 5000);
        };

        ws.onerror = () => {
          // Silent fail for connection errors to avoid console noise
          ws?.close();
        };
      } catch (e) {
        reconnectTimeout = setTimeout(connect, 5000);
      }
    };

    connect();

    return () => {
      if (ws) ws.close();
      if (reconnectTimeout) clearTimeout(reconnectTimeout);
      if (heartbeatInterval) clearInterval(heartbeatInterval);
    };
  }, []);

  const fetchViolations = async () => {
    try {
      const res = await fetch('/api/violations');
      const data = await res.json();
      setViolations(data);
    } catch (err) {
      console.error('Failed to fetch violations:', err);
    }
  };

  const fetchLoginLogs = async () => {
    try {
      const res = await fetch('/api/admin/login-logs');
      const data = await res.json();
      setLoginLogs(data);
    } catch (err) {
      console.error('Failed to fetch login logs:', err);
    }
  };

  const handleUpload = async (file: File) => {
    setIsUploading(true);
    setError(null);
    
    const formData = new FormData();
    formData.append('video', file);

    try {
      // 1. Upload
      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!uploadRes.ok) throw new Error('Upload failed');
      const { videoPath, filename } = await uploadRes.json();
      setCurrentVideo(videoPath);

      // 2. Analyze
      const analyzeRes = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ videoPath, filename }),
      });

      if (!analyzeRes.ok) throw new Error('Analysis failed');
      
      await fetchViolations();
    } catch (err: any) {
      setError(err.message || 'Something went wrong during processing');
    } finally {
      setIsUploading(false);
    }
  };

  const handleLogin = async (email: string) => {
    setIsAuthenticated(true);
    setUserEmail(email);
    
    // Notify admin about the login
    try {
      await fetch('/api/auth/login-notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
    } catch (err) {
      console.error('Failed to send login notification:', err);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserEmail(null);
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex min-h-screen bg-zinc-50">
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-200 bg-white p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-10 h-10 bg-zinc-900 rounded-xl flex items-center justify-center text-white">
            <Shield className="w-6 h-6" />
          </div>
          <h1 className="font-bold text-xl tracking-tight">TrafficGuard</h1>
        </div>

        <nav className="space-y-1 flex-1">
          <NavItem 
            icon={<LayoutDashboard className="w-5 h-5" />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<Activity className="w-5 h-5" />} 
            label="Live Feed" 
            active={activeTab === 'live'} 
            onClick={() => setActiveTab('live')} 
          />
          <NavItem 
            icon={<FileText className="w-5 h-5" />} 
            label="Reports" 
            active={activeTab === 'reports'} 
            onClick={() => setActiveTab('reports')} 
          />
          <NavItem 
            icon={<Settings className="w-5 h-5" />} 
            label="Settings" 
            active={activeTab === 'settings'} 
            onClick={() => setActiveTab('settings')} 
          />
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all duration-200 mt-2"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </nav>

        <div className="mt-auto p-4 bg-zinc-50 rounded-2xl">
          <div className="flex items-center gap-3 mb-2">
            <div className={cn(
              "w-2 h-2 rounded-full",
              wsStatus === 'connected' ? "bg-emerald-500 animate-pulse" : "bg-amber-500 animate-bounce"
            )} />
            <span className="text-xs font-semibold text-zinc-600 uppercase tracking-wider">
              {wsStatus === 'connected' ? 'System Active' : 'Reconnecting...'}
            </span>
          </div>
          <p className="text-[10px] text-zinc-400 font-mono">v1.0.4-stable</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        <header className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-zinc-900">
              {activeTab === 'dashboard' ? 'Traffic Analysis Dashboard' : 
               activeTab === 'live' ? 'Live AI Monitoring' :
               activeTab === 'reports' ? 'Violation Reports' : 'Settings'}
            </h2>
            <p className="text-zinc-500">
              {activeTab === 'live' ? 'Real-time computer vision analysis of traffic flow.' : 
               activeTab === 'settings' ? 'Configure AI detection engine and system preferences.' :
               'Monitor and detect traffic violations in real-time.'}
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex -space-x-2">
              {[1, 2, 3].map(i => (
                <img 
                  key={i}
                  src={`https://picsum.photos/seed/${i}/32/32`} 
                  className="w-8 h-8 rounded-full border-2 border-white"
                  alt="User"
                  referrerPolicy="no-referrer"
                />
              ))}
            </div>
            <button className="p-2 text-zinc-400 hover:text-zinc-900 transition-colors">
              <Settings className="w-6 h-6" />
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'live' && (
            <motion.div
              key="live"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <LiveFeed />
            </motion.div>
          )}

          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-8"
            >
              <div className="lg:col-span-2 space-y-8">
                {/* Upload Section */}
                <section className="glass rounded-3xl p-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold">Process New Footage</h3>
                    {isUploading && (
                      <div className="flex items-center gap-2 text-emerald-600 text-sm font-medium">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        AI Analysis in progress...
                      </div>
                    )}
                  </div>
                  
                  <VideoUpload onUpload={handleUpload} isUploading={isUploading} />
                  
                  {error && (
                    <div className="mt-4 p-4 bg-red-50 border border-red-100 rounded-xl flex items-center gap-3 text-red-600 text-sm">
                      <AlertCircle className="w-5 h-5" />
                      {error}
                    </div>
                  )}
                </section>

                {/* Video Preview */}
                {currentVideo && (
                  <section className="glass rounded-3xl overflow-hidden">
                    <div className="p-4 border-b border-zinc-100 flex items-center justify-between">
                      <h3 className="font-bold text-sm uppercase tracking-wider text-zinc-500">Active Footage</h3>
                      <div className="flex items-center gap-2 text-xs font-medium text-emerald-600">
                        <CheckCircle2 className="w-4 h-4" />
                        Processed
                      </div>
                    </div>
                    <video 
                      src={currentVideo} 
                      controls 
                      className="w-full aspect-video bg-black"
                    />
                  </section>
                )}

                {/* Stats Grid */}
                <div className="grid grid-cols-3 gap-4">
                  <StatCard label="Total Violations" value={violations.length} trend="+12%" />
                  <StatCard label="Helmet Violations" value={violations.filter(v => v.violation_type.toLowerCase().includes('helmet')).length} trend="+5%" />
                  <StatCard label="Accuracy Rate" value="98.4%" trend="+0.2%" />
                </div>

                {/* Traffic Light Preview */}
                <section className="glass rounded-3xl p-8 flex flex-col items-center">
                  <h3 className="text-lg font-bold mb-4 self-start">Signal Status Preview</h3>
                  <div className="signal">
                    <div className="light red"></div>
                    <div className="light yellow"></div>
                    <div className="light green"></div>
                  </div>
                  <p className="text-xs text-zinc-400 mt-4">Simulated AI-controlled traffic signal based on current flow.</p>
                </section>
              </div>

              {/* Sidebar: Recent Violations */}
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold">Recent Detections</h3>
                  <button className="text-xs font-bold text-zinc-400 hover:text-zinc-900 transition-colors uppercase tracking-widest">View All</button>
                </div>
                <div className="max-h-[calc(100vh-250px)] overflow-y-auto pr-2 custom-scrollbar">
                  <ViolationList violations={violations} />
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'reports' && (
            <motion.div
              key="reports"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <div className="glass rounded-3xl p-8">
                <h3 className="text-xl font-bold mb-6">Detailed Violation Reports</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-zinc-100">
                        <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">ID</th>
                        <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Type</th>
                        <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Timestamp</th>
                        <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Plate</th>
                        <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Date</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-50">
                      {violations.map(v => (
                        <tr key={v.id} className="hover:bg-zinc-50 transition-colors">
                          <td className="py-4 text-sm font-mono text-zinc-400">#{v.id}</td>
                          <td className="py-4">
                            <span className={cn(
                              "px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                              v.violation_type.toLowerCase().includes('helmet') ? "bg-orange-100 text-orange-700" :
                              v.violation_type.toLowerCase().includes('seatbelt') ? "bg-blue-100 text-blue-700" :
                              "bg-red-100 text-red-700"
                            )}>
                              {v.violation_type}
                            </span>
                          </td>
                          <td className="py-4 text-sm font-medium text-zinc-600">{v.timestamp}</td>
                          <td className="py-4 text-sm font-mono text-zinc-900">{v.license_plate || 'N/A'}</td>
                          <td className="py-4 text-sm text-zinc-400">
                            {v.created_at ? new Date(v.created_at).toLocaleDateString() : 'Today'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <LoginLogsSection />
            </motion.div>
          )}

          {activeTab === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <SettingsView />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick, disabled = false }: { 
  icon: React.ReactNode, 
  label: string, 
  active: boolean, 
  onClick?: () => void,
  disabled?: boolean
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200",
        active ? "bg-zinc-900 text-white shadow-lg shadow-zinc-200" : "text-zinc-500 hover:bg-zinc-100",
        disabled && "opacity-40 cursor-not-allowed"
      )}
    >
      {icon}
      <span className="font-medium">{label}</span>
      {active && (
        <motion.div 
          layoutId="active-pill" 
          className="ml-auto w-1.5 h-1.5 bg-white rounded-full" 
        />
      )}
    </button>
  );
}

function StatCard({ label, value, trend }: { label: string, value: string | number, trend: string }) {
  return (
    <div className="glass p-6 rounded-3xl">
      <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2">{label}</p>
      <div className="flex items-end justify-between">
        <h4 className="text-3xl font-bold text-zinc-900">{value}</h4>
        <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-1 rounded-lg">
          {trend}
        </span>
      </div>
    </div>
  );
}

function LoginLogsSection() {
  const [logs, setLogs] = useState<any[]>([]);

  useEffect(() => {
    fetch('/api/admin/login-logs')
      .then(res => res.json())
      .then(data => setLogs(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div className="glass rounded-3xl p-8">
      <h3 className="text-xl font-bold mb-6">Security: Recent Login Activity</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-zinc-100">
              <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">User Email</th>
              <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Time</th>
              <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">IP Address</th>
              <th className="pb-4 font-bold text-xs uppercase tracking-wider text-zinc-400">Device</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-50">
            {logs.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-8 text-center text-zinc-400 italic">No login activity recorded yet.</td>
              </tr>
            ) : (
              logs.map(log => (
                <tr key={log.id} className="hover:bg-zinc-50 transition-colors">
                  <td className="py-4 text-sm font-medium text-zinc-900">{log.user_email}</td>
                  <td className="py-4 text-sm text-zinc-500">{new Date(log.login_time).toLocaleString()}</td>
                  <td className="py-4 text-sm font-mono text-zinc-400">{log.ip_address}</td>
                  <td className="py-4 text-sm text-zinc-400 truncate max-w-[200px]" title={log.user_agent}>
                    {log.user_agent}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
