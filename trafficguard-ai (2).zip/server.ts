import express from "express";
import { createServer as createViteServer } from "vite";
import multer from "multer";
import path from "path";
import fs from "fs";
import Database from "better-sqlite3";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { WebSocketServer, WebSocket } from "ws";
import { createServer } from "http";
import nodemailer from "nodemailer";

dotenv.config();

const db = new Database("traffic.db");

// Initialize DB
db.exec(`
  CREATE TABLE IF NOT EXISTS violations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    video_path TEXT,
    timestamp TEXT,
    violation_type TEXT,
    description TEXT,
    license_plate TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS login_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_email TEXT,
    login_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    ip_address TEXT,
    user_agent TEXT
  );
`);

async function startServer() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ noServer: true });
  const PORT = 3000;

  // Handle manual WebSocket upgrade to avoid conflicts with Vite/Express
  server.on('upgrade', (request, socket, head) => {
    const pathname = new URL(request.url || '', `http://${request.headers.host}`).pathname;

    if (pathname === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    } else {
      socket.destroy();
    }
  });

  // Email Transporter (Lazy initialization)
  const getTransporter = () => {
    const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;
    if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
      console.warn("SMTP settings missing. Email notifications will be skipped.");
      return null;
    }
    return nodemailer.createTransport({
      host: SMTP_HOST,
      port: parseInt(SMTP_PORT),
      secure: parseInt(SMTP_PORT) === 465,
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
  };

  // Track connected clients
  const clients = new Set<WebSocket>();

  wss.on("connection", (ws) => {
    clients.add(ws);
    console.log("New WebSocket client connected");
    
    ws.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString());
        if (message.type === "PING") {
          ws.send(JSON.stringify({ type: "PONG" }));
        }
      } catch (e) {
        // Ignore
      }
    });

    ws.on("close", () => {
      clients.delete(ws);
      console.log("WebSocket client disconnected");
    });
  });

  const broadcastViolation = (violation: any) => {
    const message = JSON.stringify({ type: "NEW_VIOLATION", data: violation });
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  app.use(express.json());

  const storage = multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) => {
      cb(null, Date.now() + path.extname(file.originalname));
    },
  });

  const upload = multer({ storage });

  if (!fs.existsSync("uploads")) {
    fs.mkdirSync("uploads");
  }

  // Auth Routes
  app.post("/api/auth/login-notify", async (req, res) => {
    const { email } = req.body;
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    try {
      // 1. Log to DB
      db.prepare("INSERT INTO login_logs (user_email, ip_address, user_agent) VALUES (?, ?, ?)").run(email, ip, userAgent);

      // 2. Send Email to Admin
      const adminEmail = process.env.ADMIN_EMAIL;
      const transporter = getTransporter();

      if (adminEmail && transporter) {
        const mailOptions = {
          from: `"TrafficGuard Security" <${process.env.SMTP_USER}>`,
          to: adminEmail,
          subject: `Security Alert: New Login Detected - ${email}`,
          html: `
            <div style="font-family: sans-serif; padding: 20px; color: #1a1a1a;">
              <h2 style="color: #000;">New Login Detected</h2>
              <p>A user has successfully signed into the TrafficGuard AI dashboard.</p>
              <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;" />
              <table style="width: 100%; border-collapse: collapse;">
                <tr><td style="padding: 8px 0; font-weight: bold;">User Email:</td><td>${email}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold;">Timestamp:</td><td>${new Date().toLocaleString()}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold;">IP Address:</td><td>${ip}</td></tr>
                <tr><td style="padding: 8px 0; font-weight: bold;">User Agent:</td><td>${userAgent}</td></tr>
              </table>
              <p style="margin-top: 30px; font-size: 12px; color: #666;">
                This is an automated security notification. If you do not recognize this activity, please investigate immediately.
              </p>
            </div>
          `,
        };

        await transporter.sendMail(mailOptions);
        console.log(`Login notification sent to admin: ${adminEmail}`);
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Login notification error:", error);
      res.status(500).json({ error: "Failed to process login notification" });
    }
  });

  app.get("/api/admin/login-logs", (req, res) => {
    const logs = db.prepare("SELECT * FROM login_logs ORDER BY login_time DESC LIMIT 100").all();
    res.json(logs);
  });

  // API Routes
  app.post("/api/upload", upload.single("video"), async (req: any, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" });
    }

    const videoPath = req.file.path;
    
    res.json({ 
      success: true, 
      videoPath: `/${videoPath}`,
      filename: req.file.filename 
    });
  });

  app.post("/api/analyze", async (req, res) => {
    const { videoPath, filename } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    console.log(`Starting analysis for: ${filename}`);

    if (!apiKey) {
      console.error("Analysis failed: GEMINI_API_KEY is missing");
      return res.status(500).json({ error: "Gemini API key not configured" });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });

      // Read video file as base64
      const fullPath = path.join(process.cwd(), videoPath.startsWith('/') ? videoPath.slice(1) : videoPath);
      
      if (!fs.existsSync(fullPath)) {
        console.error(`Analysis failed: File not found at ${fullPath}`);
        return res.status(404).json({ error: "Video file not found" });
      }

      const videoData = fs.readFileSync(fullPath).toString("base64");
      console.log(`Video loaded, size: ${(videoData.length / 1024 / 1024).toFixed(2)} MB`);

      const prompt = `
        Analyze this traffic video for violations. 
        Detect:
        1. Motorcyclists without helmets.
        2. Drivers/passengers without seatbelts.
        3. Any other traffic rule violations (e.g., running red lights, illegal turns).
        4. Extract license plate numbers for any vehicles involved in violations if visible.

        Return the results as a JSON array of objects.
      `;

      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [
          {
            parts: [
              { text: prompt },
              {
                inlineData: {
                  mimeType: "video/mp4",
                  data: videoData,
                },
              },
            ],
          },
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                timestamp: {
                  type: Type.STRING,
                  description: "The time in the video where the violation occurs, e.g., '0:12'",
                },
                type: {
                  type: Type.STRING,
                  description: "The category of violation, e.g., 'No Helmet', 'No Seatbelt', 'Red Light'",
                },
                description: {
                  type: Type.STRING,
                  description: "A detailed description of what happened.",
                },
                licensePlate: {
                  type: Type.STRING,
                  description: "The license plate of the vehicle, or null if not visible.",
                },
              },
              required: ["timestamp", "type", "description"],
            },
          },
        },
      });

      const responseText = result.text;
      console.log("Gemini response received");
      
      if (!responseText) {
        console.warn("Gemini returned an empty response");
        return res.json({ success: true, violations: [] });
      }

      const violations = JSON.parse(responseText);
      console.log(`Detected ${violations.length} violations`);

      // Save to DB and broadcast
      const insert = db.prepare(`
        INSERT INTO violations (video_path, timestamp, violation_type, description, license_plate)
        VALUES (?, ?, ?, ?, ?)
      `);

      for (const v of violations) {
        const info = insert.run(videoPath, v.timestamp, v.type, v.description, v.licensePlate || null);
        broadcastViolation({
          id: info.lastInsertRowid,
          video_path: videoPath,
          timestamp: v.timestamp,
          violation_type: v.type,
          description: v.description,
          license_plate: v.licensePlate || null,
          created_at: new Date().toISOString()
        });
      }

      res.json({ success: true, violations });
    } catch (error: any) {
      console.error("Analysis error:", error);
      res.status(500).json({ error: error.message || "Internal server error during analysis" });
    }
  });

  app.get("/api/violations", (req, res) => {
    const rows = db.prepare("SELECT * FROM violations ORDER BY created_at DESC").all();
    res.json(rows);
  });

  // Serve uploaded files
  app.use("/uploads", express.static("uploads"));

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: false // Explicitly disable HMR to prevent "failed to connect" console errors
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist/index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
